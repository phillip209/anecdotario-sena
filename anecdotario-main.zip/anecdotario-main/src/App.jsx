import { useState } from 'react';
import "./styles.css";

// Componentes títulos (h1 y h2)
const Title = ({ level }) => {
  if (level === 'h1') return <h1>Anecdote of the day</h1>;
  if (level === 'h2') return <h2>Anecdote with most votes</h2>;
  return null;
};

// Componente botones
const Button = ({ onClick, children }) => (
  <button onClick={onClick}>{children}</button>
);

// Componente que muestra una anécdota, etc
const Anecdote = ({ text, votes, onVote, onNext, fadeKey }) => (
  <div key={fadeKey} className="fade">
    <p>{text}</p>
    <p>has {votes} votes</p>
    <Button onClick={onVote}>Vote</Button>
    <Button onClick={onNext}>Next anecdote</Button>
  </div>
);

const App = () => {
  const [anecdotes, setAnecdotes] = useState([
    'If it hurts, do it more often.',
    'Adding manpower to a late software project makes it later!',
    'The first 90 percent of the code accounts for the first 10 percent of the development time...',
    'Any fool can write code that a computer can understand. Good programmers write code that humans can understand.',
    'Premature optimization is the root of all evil.',
    'Debugging is twice as hard as writing the code in the first place.',
    'Programming without console.log is like a doctor without x-rays.',
    'The only way to go fast, is to go well.'
  ]);

  const [selected, setSelected] = useState(0);
  const [votes, setVotes] = useState(Array(anecdotes.length).fill(0)); 
  const [newAnecdote, setNewAnecdote] = useState('');
  const [fadeKey, setFadeKey] = useState(0); 

  // Selección de anécdota aleatoriamente
  const handleNext = () => {
    let rand;
    do {
      rand = Math.floor(Math.random() * anecdotes.length);
    } while (rand === selected && anecdotes.length > 1);
    setSelected(rand);
    setFadeKey(prev => prev + 1); 
  };

  // Vota por la anécdota actual
  const handleVote = () => {
    const copy = [...votes];
    copy[selected] += 1;
    setVotes(copy);
  };

  // Agrega una nueva anécdota si no está vacía ni duplicada
  const handleAdd = () => {
    const trimmed = newAnecdote.trim();
    if (trimmed === '' || anecdotes.includes(trimmed)) return;
    setAnecdotes([...anecdotes, trimmed]);
    setVotes([...votes, 0]);
    setNewAnecdote('');
  };

  // Anécdota más votada
  const mostVotedIndex = votes.indexOf(Math.max(...votes));
  const maxVote = Math.max(...votes);

  return (
    <div className="container">
      <Title level="h1" />

      <Anecdote
        text={anecdotes[selected]}
        votes={votes[selected]}
        onVote={handleVote}
        onNext={handleNext}
        fadeKey={fadeKey}
      />

      <Title level="h2" />
      <p>{anecdotes[mostVotedIndex]}</p>
      <p>has {votes[mostVotedIndex]} votes</p>

      <h3>Vote Chart</h3>
      <div className="chart">
        {anecdotes.map((a, i) => (
          <div key={i} className="bar-row">
            <div
              className="bar"
              style={{
                width: maxVote ? `${(votes[i] / maxVote) * 100}%` : '0%',
                backgroundColor: '#FFDB58',
                height: '20px',
              }}
            ></div>
            <span>{votes[i]}</span>
          </div>
        ))}
      </div>

      <h3>Add a new anecdote</h3>
      <input
        type="text"
        placeholder="Your anecdote"
        value={newAnecdote}
        onChange={(e) => setNewAnecdote(e.target.value)}
      />
      <Button onClick={handleAdd}>Add</Button>
    </div>
  );
};

export default App;
